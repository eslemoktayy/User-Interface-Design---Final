'.owl-carousel'
$('.owl-carousel').owlCarousel();
$('.owl-carousel').owlCarousel({
    items: 3, // Number of items to display
    autoplay: true, // Enable autoplay
  });